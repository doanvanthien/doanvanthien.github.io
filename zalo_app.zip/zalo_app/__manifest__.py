# -*- coding: utf-8 -*-
{
    'name': "zalo app",
    'summary': """
    zalo app
    """,
    'description': """
        zalo app
    """,
    'author': "TDV",
    'website': "http://www.thiendv.vn",
    'category': 'Zalo',
    'version': '0.1',
    'depends': ['base'],
    'data': [
        'data/data.xml',
        'views/zalo_config_views.xml',
        'views/zalo_views.xml',
    ],
}
